#include "controler_task.h"
#include "chassis_task.h"
#include "EZ_RTOS.h"
#include "bsp_fdcan.h"
#include "uart_bsp.h"
#include "usart.h"
#include "gpio.h"
ctrl_mode_e ctrl_mode;

#define ARR1 20000
#define ARR2 20000

#define defaultCH 992
#define MaxCH 1792
#define MinCH 192

const float sc = 0.01f;

uint8_t ch_signal_effective[10];

typedef enum {
    CH_STATE_MID = 0,
    CH_STATE_UP = 1,
    CH_STATE_DOWN = 2
} ch_state_e;

static ch_state_e ch5_last_state = CH_STATE_MID;
static ch_state_e ch6_last_state = CH_STATE_MID;
static uint8_t first_entry = 1;

static ch_state_e get_ch_state(int16_t ch_val)
{
    if (ch_val > (defaultCH + 20))
        return CH_STATE_UP;
    else if (ch_val < (defaultCH - 20))
        return CH_STATE_DOWN;
    else
        return CH_STATE_MID;
}
  
void controler_task(void)
{
    remoteHandler();
		task_delay(5);
}

int abs(int x) {
    return x < 0 ? -x : x;
}

void remoteHandler(void)
{
		ctrl_mode =
    (remoter.rc.ch[7] < (defaultCH - 20)) ? PROTECT_MODE :
    (remoter.rc.ch[7] > (defaultCH + 20)) ? AUTO_MODE :
    REMOTER_MODE;
		if(remoter.rc.ch[7] == 0)
		{
			HAL_UARTEx_ReceiveToIdle_DMA(&huart5, rx_buff, BUFF_SIZE*2);
			ctrl_mode = PROTECT_MODE;
		}
	if(ctrl_mode == REMOTER_MODE)
	{
	 ch_signal_effective[1] = (remoter.rc.ch[1] < (defaultCH - 20)||remoter.rc.ch[1] > (defaultCH + 20))?1:0;
	 ch_signal_effective[0] = (remoter.rc.ch[0] < (defaultCH - 20)||remoter.rc.ch[0] > (defaultCH + 20))?1:0;
	 ch_signal_effective[3] = (remoter.rc.ch[3] < (defaultCH - 20)||remoter.rc.ch[3] > (defaultCH + 20))?1:0;
	 
	 chassis.spd_input.vy = (float)((ch_signal_effective[1])?(remoter.rc.ch[1] - defaultCH)*sc:0);
	 chassis.spd_input.vx = (float)((ch_signal_effective[0])?(remoter.rc.ch[0] - defaultCH)*sc:0);
	 chassis.spd_input.vw = (float)((ch_signal_effective[3])?(remoter.rc.ch[3] - defaultCH)*sc:0);
	 
	 if(remoter.rc.ch[4] > (defaultCH + 200))
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_2,GPIO_PIN_RESET);
	 else
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_2,GPIO_PIN_SET);
	 if(remoter.rc.ch[4] < (defaultCH - 200))
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_0,GPIO_PIN_RESET);
	 else
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_0,GPIO_PIN_SET);
	}
	else if(ctrl_mode == AUTO_MODE)
	{
		chassis.spd_input.vy = can_spd_input.vy*sc;
		chassis.spd_input.vx = can_spd_input.vx*sc;
		chassis.spd_input.vw = can_spd_input.vw*sc;
		
		if(can_spd_input.updown == 2)
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_2,GPIO_PIN_RESET);
		else
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_2,GPIO_PIN_SET);
		if(can_spd_input.updown == 1)
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_0,GPIO_PIN_RESET);
		else
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_0,GPIO_PIN_SET);
	}
	else if(ctrl_mode == PROTECT_MODE)
	{
		if(can_spd_input.updown == 2)
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_2,GPIO_PIN_RESET);
		else
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_2,GPIO_PIN_SET);
		if(can_spd_input.updown == 1)
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_0,GPIO_PIN_RESET);
		else
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_0,GPIO_PIN_SET);
		
		ch_state_e ch5_state = get_ch_state(remoter.rc.ch[5]);
		ch_state_e ch6_state = get_ch_state(remoter.rc.ch[6]);
		
		if(first_entry)
		{
			ch5_last_state = ch5_state;
			ch6_last_state = ch6_state;
			first_entry = 0;
		}
		
		if(ch5_state != ch5_last_state && ch5_state != CH_STATE_MID)
		{
			uint8_t txdata[8] = {0};
			txdata[0] = 0x50;
			txdata[7] = (ch5_state == CH_STATE_UP) ? 0x01 : 0x02;
			fdcanx_send_data(&hfdcan2, 0x052, txdata, 8);
			ch5_last_state = ch5_state;
		}
		
		if(ch6_state != ch6_last_state && ch6_state != CH_STATE_MID)
		{
			uint8_t txdata[8] = {0};
			txdata[0] = 0x60;
			txdata[7] = (ch6_state == CH_STATE_UP) ? 0x01 : 0x02;
			fdcanx_send_data(&hfdcan2, 0x052, txdata, 8);
			ch6_last_state = ch6_state;
		}
	}
	else
	{
		first_entry = 1;
	}
}




